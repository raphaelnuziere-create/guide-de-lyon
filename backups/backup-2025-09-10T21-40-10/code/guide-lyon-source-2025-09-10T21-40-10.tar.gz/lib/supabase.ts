// Re-export du client singleton depuis app/lib/supabase/client
export { supabase } from '@/app/lib/supabase/client';