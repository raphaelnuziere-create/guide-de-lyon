// Import de la page simplifiée temporairement
import SimpleEstablishmentPage from './simple-page'

export default function DynamicEstablishmentPage() {
  return <SimpleEstablishmentPage />
}