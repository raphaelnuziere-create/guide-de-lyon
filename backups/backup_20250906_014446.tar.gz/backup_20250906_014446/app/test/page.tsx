export default function TestPage() {
  return (
    <h1>TEST PAGE - Si vous voyez ceci, le déploiement fonctionne!</h1>
  )
}